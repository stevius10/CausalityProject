# Progress Log

All updates and changes to the model are documented here.